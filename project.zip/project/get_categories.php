<?php
// Database connection parameters
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$database = "project"; // Change this to your MySQL database namename

// Establishing connection to MySQL database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to retrieve categories from 'categories' table
$sql = "SELECT category_name FROM categories";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while($row = $result->fetch_assoc()) {
        echo "<option value='" . $row["category_name"] . "'>" . $row["category_name"] . "</option>";
    }
} else {
    echo "<option value=''>No categories found</option>";
}

// Close MySQL connection
$conn->close();
?>

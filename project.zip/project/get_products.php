<?php
// Database connection parameters
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$database = "project"; // Change this to your MySQL database name

// Establishing connection to MySQL database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// If category name is provided via GET request
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET["category"])) {
    $categoryName = $_GET["category"];

    // SQL query to retrieve product name and price belonging to the specified category from 'products' table
    $sql = "SELECT product_name, product_price FROM products WHERE product_category = ?";
    
    // Prepare and bind the query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $categoryName);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Output product details in table format
        echo "<tr><th>Product Name</th><th>Product Price</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr><td>" . $row["product_name"] . "</td><td>" . $row["product_price"] . "</td></tr>";
        }
    } else {
        echo "<tr><td colspan='2'>No products found for this category</td></tr>";
    }
    $stmt->close();
} else {
    echo "<tr><td colspan='2'>Invalid request</td></tr>";
}

// Close MySQL connection
$conn->close();
?>

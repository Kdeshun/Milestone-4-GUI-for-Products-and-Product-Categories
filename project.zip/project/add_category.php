<?php
// Database connection parameters
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$database = "project"; // Change this to your MySQL database name

// Establishing connection to MySQL database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if category name is provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["categoryName"])) {
    $categoryName = $_POST["categoryName"];

    // SQL query to insert category into 'categories' table
    $sql = "INSERT INTO categories (category_name) VALUES (?)";
    
    // Prepare and bind the query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $categoryName);

    // Execute the query
    if ($stmt->execute()) {
        echo "Category added successfully";
    } else {
        echo "Error adding category: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Invalid request";
}

// Close MySQL connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Product Management</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    h2 {
        text-align: center;
    }
    .container {
        display: flex;
        justify-content: center;
        align-items: flex-start;
        margin-top: 50px;
    }
    .left-section, .right-section {
        width: 45%;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    .left-section {
        border-right: 1px solid #ccc;
    }
    .form-group {
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 8px;
        font-weight: bold;
    }
    input[type="text"] {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    button {
        padding: 10px 20px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }
    button:hover {
        background-color: #0056b3;
    }
    select {
        width: 100%;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        border: 1px solid #ccc;
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
</style>
</head>
<body>

<h2>Product Management</h2>

<div class="container">
    <div class="left-section">
        <h3>Add Product</h3>
        <div class="form-group">
            <label for="productName">Product Name:</label>
            <input type="text" id="productName" placeholder="Enter product name">
        </div>
        <div class="form-group">
            <label for="productDescription">Product Description:</label>
            <input type="text" id="productDescription" placeholder="Enter product description">
        </div>
        <div class="form-group">
            <label for="productCategory">Product Category:</label>
            <input type="text" id="productCategory" placeholder="Enter product category">
        </div>
        <button onclick="addProduct()">Add Product</button>

        <h3>Add Category</h3>
        <div class="form-group">
            <label for="categoryName">Category Name:</label>
            <input type="text" id="categoryName" placeholder="Enter category name">
        </div>
        <button onclick="addCategory()">Add Category</button>
    </div>

    <div class="right-section">
        <h3>Product Details</h3>
        <select id="categorySelect" onchange="showCategoryProducts()">
            <option value="">Select a category</option>
        </select>

        <table id="productTable">
            <tr>
                <th>Product Name</th>
                <th>Product Price</th>
            </tr>
        </table>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
    // Function to load categories from database and display product details based on the selected category
    function showCategoryProducts() {
        var selectedCategory = $("#categorySelect").val();
        if (selectedCategory !== "") {
            // Send AJAX request to get products belonging to the selected category
            $.get("get_products.php", { category: selectedCategory }, function(data, status) {
                $("#productTable").html(data); // Update product table with products belonging to the selected category
            });
        } else {
            // If no category is selected, reset product table
            $("#productTable").html("<tr><th>Product Name</th><th>Product Price</th></tr>");
        }
    }

    // Function to load categories from database
    $(document).ready(function() {
        // Send AJAX request to get categories from database
        $.get("get_categories.php", function(data, status) {
            $("#categorySelect").html(data); // Populate category select element with categories
        });
    });

    // Function to add a new product
    function addProduct() {
        var productName = $("#productName").val();
        var productDescription = $("#productDescription").val();
        var productCategory = $("#productCategory").val();

        // Send AJAX request to add product to the database
        $.post("add_product.php", {
            productName: productName,
            productDescription: productDescription,
            productCategory: productCategory
        }, function(data, status) {
            alert(data); // Alert response from PHP script
        });
    }

    // Function to add a new category
    function addCategory() {
        var categoryName = $("#categoryName").val();

        // Send AJAX request to add category to the database
        $.post("add_category.php", {
            categoryName: categoryName
        }, function(data, status) {
            alert(data); // Alert response from PHP script
            // Refresh category select options after adding new category
            $.get("get_categories.php", function(data, status) {
                $("#categorySelect").html(data);
            });
        });
    }
</script>

</body>
</html>

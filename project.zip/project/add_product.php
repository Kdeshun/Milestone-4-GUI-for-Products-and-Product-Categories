<?php
// Database connection parameters
$servername = "localhost"; // Change this to your MySQL server hostname
$username = "root"; // Change this to your MySQL username
$password = ""; // Change this to your MySQL password
$database = "project"; // Change this to your MySQL database name

// Establishing connection to MySQL database
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if all required fields are provided
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["productName"]) && isset($_POST["productDescription"]) && isset($_POST["productCategory"])) {
    $productName = $_POST["productName"];
    $productDescription = $_POST["productDescription"];
    $productCategory = $_POST["productCategory"];

    // SQL query to insert product into 'products' table
    $sql = "INSERT INTO products (product_name, product_description, product_category) VALUES (?, ?, ?)";
    
    // Prepare and bind the query
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $productName, $productDescription, $productCategory);

    // Execute the query
    if ($stmt->execute()) {
        echo "Product added successfully";
    } else {
        echo "Error adding product: " . $conn->error;
    }

    $stmt->close();
} else {
    echo "Invalid request";
}

// Close MySQL connection
$conn->close();
?>
